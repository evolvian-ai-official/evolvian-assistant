// src/constants/clientIds.js
export const INTERNAL_PUBLIC_CLIENT_ID = "evolvian00001";
