export default function TestTailwind() {
  return (
    <div className="min-h-screen bg-red-500 text-white flex items-center justify-center">
      <h1 className="text-4xl font-bold">Tailwind funciona correctamente</h1>
    </div>
  );
}
